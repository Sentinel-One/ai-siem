This parser was created for customer Coats.
Log Ingested via HEC and structured /event endpoint